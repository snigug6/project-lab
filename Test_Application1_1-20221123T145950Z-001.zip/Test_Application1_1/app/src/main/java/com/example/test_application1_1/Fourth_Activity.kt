package com.example.test_application1_1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Fourth_Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fourth)
    }
}